<!DOCTYPE html>
<html>


<head>
	<meta charset="utf-8">
	<title></title>
</head>


<body>

	<div class="container">

		<div class="row">

			<div class="col-md-1">
				
			</div>


			<div class="col-md-10">
				<br>
				<h4><?php echo date("D-d-M-Y      h:i A"); ?></h4> <br> <br>

				<h4></h4>

				<div class="row" style="padding-top:50px ;">

					<!-- <div class="col-md-2">

					
					
					</div> -->


					<div class="col-md-12">

				
						<p style="font-size: 25px; text-align: justify;">
							<b>Welcome to our graphical password website!</b> We're excited to have you here and we hope you'll find our platform to be a convenient and secure way to protect your online accounts.
						</p>

						
						<br>

						

						<p style="font-size: 25px; text-align: justify;">
							Thank you for visiting our website, and we hope to have you as a valued user of our platform!
						</p>


					</div>



					<!-- <div class="col-md-2">
				
					</div> -->
			
				
				</div>

			</div>

			<div class="col-md-2">
				
			</div>
		
		</div>

	</div>

</body>

</html>